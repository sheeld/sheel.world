<?php 
/*
 * functions
 * semplice.child.theme
 */